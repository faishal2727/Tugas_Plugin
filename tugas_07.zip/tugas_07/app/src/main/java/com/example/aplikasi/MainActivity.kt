package com.example.aplikasi

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tombol1.setOnClickListener {
            startActivity(Intent(this,profil::class.java))
        }
        tombol2.setOnClickListener {
                val youtube = Intent(Intent.ACTION_VIEW)
                youtube.setData(Uri.parse("https://www.youtube.com/"))
                startActivity(youtube)

        }
        tombol3.setOnClickListener {
            finish()
        }
        tombol4.setOnClickListener {
            startActivity(Intent(this,parsing::class.java))
            finish()
        }

    }
}