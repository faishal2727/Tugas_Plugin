package com.example.aplikasi

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_parsing.*

class parsing : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_parsing)

        button1.setOnClickListener {
            val pertama = edit1.text.toString()
            val kedua = edit2.text.toString()

            Intent(Intent(this,hasilparsing::class.java)).also {
                it.putExtra("first",pertama)
                it.putExtra("second",kedua)
                startActivity(it)
            }
        }
        button2.setOnClickListener {
            startActivity(Intent(this,MainActivity::class.java))
            finish()
        }

    }
}